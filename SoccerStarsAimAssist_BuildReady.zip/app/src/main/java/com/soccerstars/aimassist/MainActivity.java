package com.soccerstars.aimassist;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int CAPTURE = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 42, 28, 28);
        root.setBackgroundColor(Color.rgb(18,18,18));

        TextView title = new TextView(this);
        title.setText("Soccer Stars Aim Assist");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("\nاین ابزار فقط مسیر احتمالی توپ را قبل از شوت روی صفحه نشان می‌دهد.\n"
                + "شوت را خودکار نمی‌زند. مسیر شامل برخورد با دیواره و مهره‌های قابل تشخیص است.\n");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(16);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button overlay = new Button(this);
        overlay.setText("۱) اجازه نمایش روی برنامه‌ها");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        root.addView(overlay, new LinearLayout.LayoutParams(-1, -2));

        Button start = new Button(this);
        start.setText("۲) شروع تحلیل صفحه");
        start.setOnClickListener(v -> MediaProjectionManagerCompat.request(this, CAPTURE));
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));

        Button stop = new Button(this);
        stop.setText("۳) توقف");
        stop.setOnClickListener(v -> stopService(new Intent(this, CaptureService.class)));
        root.addView(stop, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("\nراهنما: بازی را باز کن، قبل از شوت صبر کن تا خط راهنما و توپ دیده شوند. "
                + "خط مسیر و دایره انتهای مسیر روی صفحه ظاهر می‌شوند.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(14);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent s = new Intent(this, CaptureService.class);
            s.putExtra("code", resultCode);
            s.putExtra("data", data);
            startForegroundService(s);
        }
    }
}
