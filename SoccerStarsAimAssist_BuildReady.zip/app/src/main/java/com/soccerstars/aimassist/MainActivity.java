package com.soccerstars.aimassist;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    static final int CAPTURE = 100;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout v=new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL); v.setPadding(32,48,32,32);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView t=new TextView(this);
        t.setText("Soccer Stars Aim Assist\n\nپیش‌بینی مسیر بدون شوت خودکار");
        t.setTextSize(22); t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER);
        v.setBackgroundColor(Color.rgb(20,20,20)); v.addView(t);
        Button o=new Button(this); o.setText("۱) فعال‌کردن Overlay");
        o.setOnClickListener(x -> {
            if(!Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:"+getPackageName())));
        }); v.addView(o);
        Button c=new Button(this); c.setText("۲) شروع Screen Capture");
        c.setOnClickListener(x -> {
            MediaProjectionManagerCompat.request(this, CAPTURE);
        }); v.addView(c);
        setContentView(v);
    }
    @Override protected void onActivityResult(int r,int code,Intent data){
        super.onActivityResult(r,code,data);
        if(r==CAPTURE && code==RESULT_OK && data!=null){
            Intent s=new Intent(this,CaptureService.class);
            s.putExtra("code",code); s.putExtra("data",data);
            startForegroundService(s);
        }
    }
}
