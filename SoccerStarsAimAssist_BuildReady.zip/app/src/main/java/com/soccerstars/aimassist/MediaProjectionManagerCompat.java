package com.soccerstars.aimassist;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;

final class MediaProjectionManagerCompat {
    static void request(Activity a,int code){
        MediaProjectionManager m=(MediaProjectionManager)a.getSystemService(Activity.MEDIA_PROJECTION_SERVICE);
        a.startActivityForResult(m.createScreenCaptureIntent(),code);
    }
}
