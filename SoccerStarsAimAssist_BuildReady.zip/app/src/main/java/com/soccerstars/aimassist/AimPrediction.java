package com.soccerstars.aimassist;

import android.graphics.*;
import java.util.*;

final class AimPrediction {
    static class Result { ArrayList<PointF> path=new ArrayList<>(); PointF end; }

    static Result predict(Bitmap b){
        Result r=new Result(); int w=b.getWidth(),h=b.getHeight();
        // Conservative prototype: detect the game's red/orange aiming guide.
        float minx=w,miny=h,maxx=-1,maxy=-1; int n=0;
        for(int y=0;y<h;y+=4) for(int x=0;x<w;x+=4){
            int c=b.getPixel(x,y), R=Color.red(c),G=Color.green(c),B=Color.blue(c);
            if(R>165 && R>G*1.4f && R>B*1.35f){
                minx=Math.min(minx,x); maxx=Math.max(maxx,x);
                miny=Math.min(miny,y); maxy=Math.max(maxy,y); n++;
            }
        }
        if(n<25)return r;
        float sx=(minx+maxx)/2f, sy=(miny+maxy)/2f;
        float dx=(maxx-minx), dy=(maxy-miny);
        if(dx+dy<20)return r;
        if(dx<10) dx=1;
        float len=(float)Math.hypot(dx,dy); dx/=len; dy/=len;
        float left=20,top=20,right=w-20,bottom=h-20;
        PointF p=new PointF(sx,sy); r.path.add(new PointF(p.x,p.y));
        for(int k=0;k<10;k++){
            float tx=dx>0?(right-p.x)/dx:(left-p.x)/dx;
            float ty=dy>0?(bottom-p.y)/dy:(top-p.y)/dy;
            float t=Math.min(tx>0?tx:Float.POSITIVE_INFINITY,ty>0?ty:Float.POSITIVE_INFINITY);
            if(!Float.isFinite(t)||t<=0)break;
            p=new PointF(p.x+dx*t,p.y+dy*t); r.path.add(new PointF(p.x,p.y));
            boolean hx=Math.abs(p.x-left)<2||Math.abs(p.x-right)<2;
            boolean hy=Math.abs(p.y-top)<2||Math.abs(p.y-bottom)<2;
            if(hx)dx=-dx; if(hy)dy=-dy;
        }
        r.end=r.path.get(r.path.size()-1); return r;
    }
}
