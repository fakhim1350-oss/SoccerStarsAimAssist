package com.soccerstars.aimassist;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PointF;
import java.util.ArrayList;
import java.util.List;

final class AimPrediction {
    static final class Result {
        final ArrayList<PointF> path = new ArrayList<>();
        final ArrayList<PointF> hits = new ArrayList<>();
        PointF end;
    }

    private static final class Circle {
        float x,y,r;
        Circle(float x,float y,float r){this.x=x;this.y=y;this.r=r;}
    }

    /*
     * Lightweight on-device vision/physics:
     *  - finds a bright aiming line
     *  - finds circular bright/colored objects
     *  - estimates playfield from non-UI pixels
     *  - traces straight segments, wall reflections and circle collisions
     *
     * It intentionally does not control input or fire the shot.
     */
    static Result predict(Bitmap src) {
        Result out = new Result();
        if (src == null) return out;

        int w=src.getWidth(), h=src.getHeight();
        int scale = Math.max(2, Math.min(6, Math.max(w,h)/500));
        Bitmap b = src;
        List<PointF> guide = findGuide(b, scale);
        if (guide.size() < 2) return out;

        PointF start = guide.get(0);
        PointF last = guide.get(guide.size()-1);
        float dx=last.x-start.x, dy=last.y-start.y;
        float len=(float)Math.hypot(dx,dy);
        if (len < 15) return out;
        dx/=len; dy/=len;

        Bounds bounds = findBounds(b, scale);
        ArrayList<Circle> objects = findObjects(b, scale, start, bounds);

        float radius = estimateRadius(objects);
        float x=start.x, y=start.y;
        float maxX=bounds.right-radius, minX=bounds.left+radius;
        float maxY=bounds.bottom-radius, minY=bounds.top+radius;
        dx*=1f; dy*=1f;

        out.path.add(new PointF(x,y));
        for (int bounce=0; bounce<12 && out.path.size()<160; bounce++) {
            float tx = Float.POSITIVE_INFINITY, ty=Float.POSITIVE_INFINITY;
            if (dx>0) tx=(maxX-x)/dx; else if(dx<0) tx=(minX-x)/dx;
            if (dy>0) ty=(maxY-y)/dy; else if(dy<0) ty=(minY-y)/dy;
            if(tx<0) tx=Float.POSITIVE_INFINITY;
            if(ty<0) ty=Float.POSITIVE_INFINITY;
            float t=Math.min(tx,ty);
            if(!Float.isFinite(t) || t<1) break;

            Circle hit=null; float hitT=t;
            for(Circle c:objects){
                if(Math.hypot(c.x-x,c.y-y) < c.r*1.3f) continue;
                float ct=rayCircle(x,y,dx,dy,c.x,c.y,c.r+radius);
                if(ct>2 && ct<hitT){hitT=ct;hit=c;}
            }

            float nx=x+dx*hitT, ny=y+dy*hitT;
            out.path.add(new PointF(nx,ny));
            x=nx; y=ny;

            if(hit!=null){
                out.hits.add(new PointF(hit.x,hit.y));
                float vx=x-hit.x, vy=y-hit.y;
                float nl=(float)Math.hypot(vx,vy);
                if(nl<0.01f) break;
                vx/=nl; vy/=nl;
                float dot=dx*vx+dy*vy;
                dx-=2*dot*vx; dy-=2*dot*vy;
                x += dx*2f; y += dy*2f;
            } else {
                boolean wallX=Math.abs(hitT-tx)<0.5f;
                boolean wallY=Math.abs(hitT-ty)<0.5f;
                if(wallX) dx=-dx;
                if(wallY) dy=-dy;
                x += dx*1.5f; y += dy*1.5f;
            }
        }
        if(out.path.size()>1) out.end=out.path.get(out.path.size()-1);
        return out;
    }

    private static float rayCircle(float x,float y,float dx,float dy,float cx,float cy,float r){
        float ox=x-cx, oy=y-cy;
        float b=2*(dx*ox+dy*oy);
        float c=ox*ox+oy*oy-r*r;
        float disc=b*b-4*c;
        if(disc<0) return Float.POSITIVE_INFINITY;
        float s=(float)Math.sqrt(disc);
        float t1=(-b-s)/2f, t2=(-b+s)/2f;
        if(t1>0) return t1;
        return t2>0?t2:Float.POSITIVE_INFINITY;
    }

    private static List<PointF> findGuide(Bitmap b,int step){
        int w=b.getWidth(),h=b.getHeight();
        ArrayList<PointF> pts=new ArrayList<>();
        // Red/orange/white high-contrast guide pixels.
        for(int y=0;y<h;y+=step) for(int x=0;x<w;x+=step){
            int c=b.getPixel(x,y), r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
            boolean red=r>165 && r>g*1.35f && r>bl*1.25f;
            boolean white=r>205 && g>205 && bl>205;
            if(red) pts.add(new PointF(x,y));
            else if(white && (r+g+bl)>700) pts.add(new PointF(x,y));
        }
        if(pts.size()<12) return new ArrayList<>();
        // PCA gives the dominant line; endpoints are projections.
        float mx=0,my=0; for(PointF p:pts){mx+=p.x;my+=p.y;}
        mx/=pts.size(); my/=pts.size();
        float xx=0,xy=0,yy=0;
        for(PointF p:pts){float a=p.x-mx,d=p.y-my;xx+=a*a;xy+=a*d;yy+=d*d;}
        float ang=0.5f*(float)Math.atan2(2*xy,xx-yy);
        float ux=(float)Math.cos(ang),uy=(float)Math.sin(ang);
        float lo=Float.POSITIVE_INFINITY,hi=Float.NEGATIVE_INFINITY;
        PointF plo=null,phi=null;
        for(PointF p:pts){float q=(p.x-mx)*ux+(p.y-my)*uy;if(q<lo){lo=q;plo=p;}if(q>hi){hi=q;phi=p;}}
        ArrayList<PointF> two=new ArrayList<>();
        two.add(plo);two.add(phi);return two;
    }

    private static class Bounds {float left,top,right,bottom;}

    private static Bounds findBounds(Bitmap b,int step){
        int w=b.getWidth(),h=b.getHeight();
        int minX=w,minY=h,maxX=0,maxY=0,count=0;
        for(int y=h/8;y<h*7/8;y+=step) for(int x=0;x<w;x+=step){
            int c=b.getPixel(x,y),r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
            boolean field=g>r*1.05f && g>bl*1.02f && g>55;
            if(field){minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);count++;}
        }
        Bounds bnd=new Bounds();
        if(count<100){bnd.left=8;bnd.top=8;bnd.right=w-8;bnd.bottom=h-8;}
        else {bnd.left=Math.max(4,minX);bnd.top=Math.max(4,minY);bnd.right=Math.min(w-4,maxX);bnd.bottom=Math.min(h-4,maxY);}
        return bnd;
    }

    private static ArrayList<Circle> findObjects(Bitmap b,int step,PointF start,Bounds bd){
        int w=b.getWidth(),h=b.getHeight();
        ArrayList<Circle> cs=new ArrayList<>();
        int cell=step*5;
        for(int cy=(int)bd.top;cy<bd.bottom;cy+=cell){
            for(int cx=(int)bd.left;cx<bd.right;cx+=cell){
                int n=0,sx=0,sy=0;
                for(int y=cy;y<Math.min((int)bd.bottom,cy+cell);y+=step)
                    for(int x=cx;x<Math.min((int)bd.right,cx+cell);x+=step){
                        int c=b.getPixel(x,y),r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
                        int hi=Math.max(r,Math.max(g,bl)), lo=Math.min(r,Math.min(g,bl));
                        if(hi>175 && (hi-lo)>35){n++;sx+=x;sy+=y;}
                    }
                if(n>=6){
                    float px=sx/(float)n,py=sy/(float)n;
                    if(Math.hypot(px-start.x,py-start.y)>35) cs.add(new Circle(px,py,Math.max(8,cell*0.55f)));
                }
            }
        }
        return cs;
    }

    private static float estimateRadius(ArrayList<Circle> cs){
        if(cs.isEmpty()) return 12f;
        float s=0;for(Circle c:cs)s+=c.r;
        return Math.max(7,Math.min(28,s/cs.size()*0.45f));
    }
}
