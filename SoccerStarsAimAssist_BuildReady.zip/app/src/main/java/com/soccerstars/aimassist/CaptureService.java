package com.soccerstars.aimassist;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.nio.ByteBuffer;

public class CaptureService extends Service {
    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay display;
    private WindowManager wm;
    private AimOverlay overlay;
    private int w,h;

    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel ch=new NotificationChannel("cap","Screen analysis",
                NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        Notification n=new Notification.Builder(this,"cap")
                .setContentTitle("Soccer Stars Aim Assist")
                .setContentText("تحلیل صفحه فعال است")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .build();
        startForeground(7,n);
    }

    @Override public int onStartCommand(Intent i,int flags,int id) {
        if(i==null) return START_NOT_STICKY;
        int resultCode=i.getIntExtra("code",-1);
        Intent data;
        if(Build.VERSION.SDK_INT>=33) data=i.getParcelableExtra("data",Intent.class);
        else data=i.getParcelableExtra("data");
        if(resultCode<0 || data==null) return START_NOT_STICKY;

        MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=m.getMediaProjection(resultCode,data);
        DisplayMetrics dm=getResources().getDisplayMetrics();
        w=dm.widthPixels; h=dm.heightPixels;
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
        display=projection.createVirtualDisplay("AimCapture",w,h,dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(),null,null);

        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        overlay=new AimOverlay(this);
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(w,h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        try { wm.addView(overlay,lp); } catch(Exception ignored) {}

        reader.setOnImageAvailableListener(r -> analyze(r),new Handler(Looper.getMainLooper()));
        return START_STICKY;
    }

    private void analyze(ImageReader r){
        Image im=null; Bitmap full=null; Bitmap frame=null;
        try{
            im=r.acquireLatestImage();
            if(im==null) return;
            Image.Plane p=im.getPlanes()[0];
            ByteBuffer buf=p.getBuffer();
            int ps=p.getPixelStride(), rs=p.getRowStride();
            int pw=w+Math.max(0,(rs-ps*w))/ps;
            full=Bitmap.createBitmap(pw,h,Bitmap.Config.ARGB_8888);
            buf.rewind(); full.copyPixelsFromBuffer(buf);
            frame=Bitmap.createBitmap(full,0,0,w,h);
            AimPrediction.Result q=AimPrediction.predict(frame);
            if(overlay!=null) overlay.setResult(q);
        }catch(Throwable ignored){
        }finally{
            if(frame!=null)frame.recycle();
            if(full!=null)full.recycle();
            if(im!=null)im.close();
        }
    }

    @Override public void onDestroy(){
        try{if(reader!=null)reader.close();}catch(Exception ignored){}
        try{if(display!=null)display.release();}catch(Exception ignored){}
        try{if(projection!=null)projection.stop();}catch(Exception ignored){}
        try{if(overlay!=null && wm!=null)wm.removeView(overlay);}catch(Exception ignored){}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i){return null;}
}
