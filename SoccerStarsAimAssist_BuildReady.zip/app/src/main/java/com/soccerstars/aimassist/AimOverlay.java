package com.soccerstars.aimassist;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.view.View;

public class AimOverlay extends View {
    private final Paint pathPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint endPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hitPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private AimPrediction.Result result;

    public AimOverlay(Context c) {
        super(c);
        pathPaint.setColor(Color.CYAN);
        pathPaint.setStyle(Paint.Style.STROKE);
        pathPaint.setStrokeWidth(5f);
        pathPaint.setStrokeCap(Paint.Cap.ROUND);

        endPaint.setColor(Color.YELLOW);
        endPaint.setStyle(Paint.Style.STROKE);
        endPaint.setStrokeWidth(6f);

        hitPaint.setColor(Color.WHITE);
        hitPaint.setStyle(Paint.Style.STROKE);
        hitPaint.setStrokeWidth(3f);
    }

    public void setResult(AimPrediction.Result r) {
        post(() -> { result = r; invalidate(); });
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (result == null || result.path.size() < 2) return;
        for (int i=1; i<result.path.size(); i++) {
            PointF a=result.path.get(i-1), b=result.path.get(i);
            c.drawLine(a.x,a.y,b.x,b.y,pathPaint);
        }
        for (PointF p: result.hits) c.drawCircle(p.x,p.y,10,hitPaint);
        if (result.end != null) {
            c.drawCircle(result.end.x,result.end.y,28,endPaint);
            c.drawCircle(result.end.x,result.end.y,4,endPaint);
        }
    }
}
