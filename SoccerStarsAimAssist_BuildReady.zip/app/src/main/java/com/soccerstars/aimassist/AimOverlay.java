package com.soccerstars.aimassist;

import android.content.*;
import android.graphics.*;
import android.view.*;

public class AimOverlay extends View {
    Paint p=new Paint(3); Paint d=new Paint(3); AimPrediction.Result r;
    public AimOverlay(Context c){super(c);p.setColor(Color.CYAN);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);
        d.setColor(Color.CYAN);d.setStyle(Paint.Style.STROKE);d.setStrokeWidth(6);}
    void set(AimPrediction.Result x){post(()->{r=x;invalidate();});}
    @Override protected void onDraw(Canvas c){
        if(r==null||r.path.size()<2)return;
        for(int i=1;i<r.path.size();i++)c.drawLine(r.path.get(i-1).x,r.path.get(i-1).y,r.path.get(i).x,r.path.get(i).y,p);
        if(r.end!=null)c.drawCircle(r.end.x,r.end.y,24,d);
    }
}
