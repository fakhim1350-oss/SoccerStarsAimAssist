# Soccer Stars Aim Assist

MediaProjection + overlay assistant. It does not automate shots. It requests screen capture, draws a trajectory with wall reflections and marks a final predicted point. The detector is heuristic and may require calibration for different boards.
