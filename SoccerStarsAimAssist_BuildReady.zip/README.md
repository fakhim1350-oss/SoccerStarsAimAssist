# Soccer Stars Aim Assist

Android overlay that analyzes the visible game screen and draws an estimated trajectory before the shot.

Features:
- screen capture through Android MediaProjection
- floating non-touch overlay
- aiming-guide detection
- estimated field boundaries
- wall reflections
- heuristic circular-object collision prediction
- final landing marker
- no automatic tapping or shooting

Important: computer vision and physics are heuristic and game-version dependent; they are not a guarantee of an exact in-game result.
