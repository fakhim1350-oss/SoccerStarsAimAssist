package com.soccerstars.aimassist;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import java.nio.ByteBuffer;

public class CaptureService extends Service {
    MediaProjection projection; ImageReader reader; WindowManager wm; AimOverlay overlay;
    int w,h;
    @Override public void onCreate(){
        super.onCreate();
        NotificationChannel ch=new NotificationChannel("cap","Capture",NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        startForeground(7,new Notification.Builder(this,"cap")
            .setContentTitle("Soccer Stars Aim Assist")
            .setContentText("Overlay فعال است").setSmallIcon(android.R.drawable.ic_menu_compass).build());
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        int code=i.getIntExtra("code",-1);
        Intent data=i.getParcelableExtra("data");
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=m.getMediaProjection(code,data);
        DisplayMetrics d=getResources().getDisplayMetrics(); w=d.widthPixels; h=d.heightPixels;
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
        projection.createVirtualDisplay("AimCapture",w,h,d.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null);
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        overlay=new AimOverlay(this);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT);
        wm.addView(overlay,p);
        reader.setOnImageAvailableListener(r -> {
            Image im=null; Bitmap b=null;
            try{
                im=r.acquireLatestImage(); if(im==null)return;
                Image.Plane pl=im.getPlanes()[0]; ByteBuffer buf=pl.getBuffer();
                int ps=pl.getPixelStride(), rs=pl.getRowStride();
                int pw=w+(rs-ps*w)/ps;
                b=Bitmap.createBitmap(pw,h,Bitmap.Config.ARGB_8888); b.copyPixelsFromBuffer(buf);
                Bitmap f=Bitmap.createBitmap(b,0,0,w,h); b.recycle();
                AimPrediction.Result q=AimPrediction.predict(f);
                overlay.set(q); f.recycle();
            }catch(Throwable ignored){} finally{if(im!=null)im.close();}
        },new Handler(Looper.getMainLooper()));
        return START_STICKY;
    }
    @Override public void onDestroy(){
        try{if(reader!=null)reader.close();}catch(Exception e){}
        try{if(projection!=null)projection.stop();}catch(Exception e){}
        try{if(overlay!=null)wm.removeView(overlay);}catch(Exception e){}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
