package com.soccerstars.aimassist;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 1001;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32,32,32,32);

        TextView title = new TextView(this);
        title.setText("Soccer Stars Aim Assist");
        title.setTextSize(24);
        root.addView(title);

        status = new TextView(this);
        status.setText("ابتدا اجازه Overlay را فعال کنید.");
        root.addView(status);

        Button overlay = new Button(this);
        overlay.setText("اجازه نمایش روی سایر برنامه‌ها");
        overlay.setOnClickListener(v -> openOverlay());
        root.addView(overlay);

        Button start = new Button(this);
        start.setText("شروع پایش");
        start.setOnClickListener(v -> requestCapture());
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("توقف");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, CaptureService.class));
            status.setText("پایش متوقف شد.");
        });
        root.addView(stop);

        setContentView(root);
    }

    private void openOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        }
    }

    private void requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.setText("ابتدا Overlay را فعال کنید.");
            openOverlay();
            return;
        }
        MediaProjectionManager m =
            (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), CAPTURE_REQUEST);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (r != CAPTURE_REQUEST) return;
        if (c != RESULT_OK || d == null) {
            status.setText("اجازه Screen Capture داده نشد.");
            return;
        }
        Intent s = new Intent(this, CaptureService.class);
        s.putExtra("resultCode", c);
        s.putExtra("projectionData", d);
        startForegroundService(s);
        status.setText("پایش فعال شد.");
    }
}
