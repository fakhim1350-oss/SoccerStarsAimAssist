package com.soccerstars.aimassist;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.WindowManager;

public class CaptureService extends Service {
    private static final String CHANNEL = "capture";
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler worker;
    private AimOverlay overlay;
    private long lastFrame;

    @Override public void onCreate() {
        super.onCreate();
        thread = new HandlerThread("capture-worker");
        thread.start();
        worker = new Handler(thread.getLooper());
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL)
            : new Notification.Builder(this);
        return b.setContentTitle("Soccer Stars Aim Assist")
            .setContentText("پایش تصویری فعال است")
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true).build();
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        try {
            startForeground(7, notification());
            int result = intent.getIntExtra("resultCode", RESULT_CANCELED);
            Intent data = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra("projectionData", Intent.class)
                : intent.getParcelableExtra("projectionData");
            if (data == null) return START_NOT_STICKY;

            MediaProjectionManager m =
                (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = m.getMediaProjection(result, data);
            if (projection == null) return START_NOT_STICKY;

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = Math.min(dm.widthPixels, 720);
            int h = Math.max(1, dm.heightPixels * w / Math.max(1,dm.widthPixels));

            reader = ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
            reader.setOnImageAvailableListener(this::frame, worker);

            display = projection.createVirtualDisplay(
                "SSAA",w,h,dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(),null,worker);

            new Handler(Looper.getMainLooper()).post(this::addOverlay);
            return START_NOT_STICKY;
        } catch (Throwable t) {
            stopSelf();
            return START_NOT_STICKY;
        }
    }

    private void addOverlay() {
        try {
            if (overlay != null) return;
            overlay = new AimOverlay(this);
            WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
            int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                -1,-1,type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
            wm.addView(overlay,p);
        } catch (Throwable ignored) {}
    }

    private void frame(ImageReader r) {
        long now = SystemClock.uptimeMillis();
        if (now-lastFrame < 180) return;
        lastFrame = now;
        Image image = null;
        try {
            image = r.acquireLatestImage();
            if (image == null || overlay == null) return;
            // Keep capture lightweight and release every image promptly.
            overlay.postInvalidate();
        } catch (Throwable ignored) {
        } finally {
            if (image != null) image.close();
        }
    }

    @Override public void onDestroy() {
        try { if(display!=null) display.release(); } catch(Throwable ignored){}
        try { if(reader!=null) reader.close(); } catch(Throwable ignored){}
        try { if(projection!=null) projection.stop(); } catch(Throwable ignored){}
        try {
            if(overlay!=null) {
                WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
                if(wm!=null) wm.removeView(overlay);
            }
        } catch(Throwable ignored){}
        if(thread!=null) thread.quitSafely();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
