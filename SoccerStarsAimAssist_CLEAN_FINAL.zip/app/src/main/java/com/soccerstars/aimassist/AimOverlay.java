package com.soccerstars.aimassist;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public class AimOverlay extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public AimOverlay(Context c) {
        super(c);
        paint.setStrokeWidth(5f);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float x=getWidth()*0.5f, y=getHeight()*0.62f;
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.CYAN);
        c.drawLine(x,y,x+getWidth()*0.22f,y-getHeight()*0.05f,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(220,255,70,70));
        c.drawCircle(x+getWidth()*0.22f,y-getHeight()*0.05f,18f,paint);
    }
}
