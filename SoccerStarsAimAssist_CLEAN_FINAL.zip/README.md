# SoccerStarsAimAssist

Clean Android project with a GitHub Actions debug APK build.

The app provides a persistent visual overlay and screen-capture service.
It does not perform automated taps or game-control actions.
